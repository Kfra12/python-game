from tkinter import *
from tkinter import ttk
from tkinter import messagebox
import sqlite3
import datetime


class QuizApp:
    def __init__(self,root,pseudo_joueur):
        self.pseudo_joueur = pseudo_joueur
        self.root= root
        self.root.title("Quiz/Niveau 1")
        
        
        self.top = self.LabelFrame(self.root)
        self.top.pack(side="top")
        
        self.label = Label(self.root, font=('Comic Sans MS', 45, "bold"),
                           text="Niveau 1", fg="#E70739", anchor="center")
        self.label.grid(row=0 ,column=0,padx=20, pady=20)
        
        self.joueur_pseudo_label =Label(self.joueur_pseudo_label, text=f"Pseudo {self.pseudo_joueur}", font=("Comic Sans", 27), bg="#77CDF0")
        self.joueur_pseudo_label.grid(row=1, column=2, padx=20, pady=20)
        
        #Fonction de récupération et affichage des questions et propositions de reponse
        
        # Connexion à la base de données
        connexion = sqlite3.connect("dbquiz.sqlite3")
        cursor = connexion.cursor()
        
        # Récupération des questions du niveau depuis la base de données
        conn = sqlite3.connect('dbquiz.sqlite3')
        conn = conn.cursor()
        conn.execute("SELECT * FROM question WHERE id_niveau = ?", (1,))
        questions = conn.fetchall()
        conn.close()

        # Variables pour le score et le numéro de question
        score_niveau1 = 0
        questions = 0

        # Fonction pour charger une nouvelle question depuis la base de données
        def charger_question():
            global score, questions

            # Vérifier si toutes les questions ont été répondues
            if numero_question >= 20:
                # Aucune autre question disponible, fin du niveau
                messagebox.showinfo("Fin du niveau", "Félicitations ! Vous avez terminé le niveau 1.")
                # Mettre à jour le score dans la base de données
                cursor.execute("UPDATE quiz SET score_niveau1 = ? WHERE id_joueur=? " , (score_niveau1,pseudo_joueur))
                conn.commit()
                return

            # Récupérer la question et les propositions depuis la base de données
            cursor.execute("SELECT id_question, question, proposition1, proposition2, proposition3, proposition4, reponse_vrai FROM question WHERE id_niveau = 1 LIMIT 1 OFFSET ?", (numero_question,))
            question_data = cursor.fetchone()

            if question_data:
                id_question, question, proposition1, proposition2, proposition3, proposition4, reponse_vrai = question_data
                # Afficher la question et les propositions sur la fenêtre
                self.label_question.config(text=question)
                self.bouton_proposition1.config(text=proposition1, command=lambda: verifier_reponse(id_question, reponse_vrai, proposition1))
                self.bouton_proposition2.config(text=proposition2, command=lambda: verifier_reponse(id_question, reponse_vrai, proposition2))
                self.bouton_proposition3.config(text=proposition3, command=lambda: verifier_reponse(id_question, reponse_vrai, proposition3))
                self.bouton_proposition4.config(text=proposition4, command=lambda: verifier_reponse(id_question, reponse_vrai, proposition4))
            else:
                messagebox.showerror("Erreur", "Une erreur s'est produite lors du chargement de la question.")
                root.destroy()

        # Fonction pour vérifier la réponse du joueur
        def verifier_reponse(id_question, reponse_vrai, reponse_joueur):
            global score_niveau1, numero_question

            if reponse_joueur == reponse_vrai:
                messagebox.showinfo("Bonne réponse", "Félicitations ! Vous avez donné la bonne réponse.")
                # Augmenter le score du joueur
                score += 1
                # Mettre à jour le score affiché sur la fenêtre
                self.label_score.config(text="Score: {}".format(score))
            else:
                messagebox.showerror("Mauvaise réponse", "Mauvaise réponse. La bonne réponse est : {}".format(reponse_vrai))

            # Charger la prochaine question
            numero_question += 1
            charger_question()

        # Création des widgets Tkinter
        self.label_score = self.Label(self.label_score, text="Score: {}".format(score), font=("Comic Sans", 16), bg="#77CDF0", fg="black")
        self.label_date = self.Label(self.label_date, text=datetime.datetime.now().strftime("%d/%m/%Y %H:%M"), font=("Comic Sans", 16), bg="#77CDF0", fg="black")

        
        self.label_question = self.Label(self.label_question, text="", font=("Comic Sans", 18), bg="#77CDF0", fg="black")

        self.bouton_proposition1 = self.Button(self.bouton_proposition1, text="", font=("Comic Sans", 14), bg="white")
        self.bouton_proposition2 = self.Button(self.bouton_proposition2, text="", font=("Comic Sans", 14), bg="white")
        self.bouton_proposition3 = self.Button(self.bouton_proposition3,text="", font=("Comic Sans", 14), bg="white")
        self.bouton_proposition4 = self.Button(self.bouton_proposition4, text="", font=("Comic Sans", 14), bg="white")

        self.bouton_retour = self.bouton_retour.Button(self.bouton_retour, text="Retour", font=("Comic Sans", 14), bg="#EEF177", command=open_jeu)
        self.bouton_sauvegarder = self.bouton_sauvegarder.Button(self.bouton_sauvegarder, text="Sauvegarder", font=("Comic Sans", 14), bg="#EEF177", command=lambda: sauvegarder_score())
        self.bouton_reinitialiser = self.bouton_reinitialiser.Button(self.bouton_reinitialiser, text="Réinitialiser", font=("Comic Sans", 14), bg="#EEF177", command=lambda: reinitialiser_jeu())
        self.bouton_quitter = self.bouton_quitter.Button(self.bouton_quitter, text="Quitter", font=("Comic Sans", 14), bg="#EEF177", command=self.quitter_jeu )

        # Placement des widgets sur la fenêtre
        self.label_score.pack()
        self.label_date.pack(anchor=self.E)

        self.label_niveau.pack(pady=20)

        self.label_question.pack(pady=20)

        self.bouton_proposition1.pack(pady=10)
        self.bouton_proposition2.pack(pady=10)
        self.bouton_proposition3.pack(pady=10)
        self.bouton_proposition4.pack(pady=10)

        self.bouton_retour.pack(side=self.LEFT, padx=10, pady=20)
        self.bouton_sauvegarder.pack(side=self.LEFT, padx=10, pady=20)
        self.bouton_reinitialiser.pack(side=self.LEFT, padx=10, pady=20)
        self.bouton_quitter.pack(side=self.RIGHT, padx=10, pady=20)

        # Charger la première question
        charger_question()

        # Fonction pour sauvegarder le score dans la base de données
        def sauvegarder_score():
            # Enregistrer les informations dans la table "quiz"
            date_jeu = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            cursor.execute("INSERT INTO quiz (date_jeu) VALUES (?)", (date_jeu,))
            connexion.commit()

            # Récupérer l'id de la date enregistrée
            id_date = cursor.lastrowid

            # Enregistrer les informations dans la table "quiz"
            date_jeu = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            cursor.execute("INSERT INTO quiz (id_joueur, id_niveau, score_nineau1) VALUES (?, ?, ?)",
                            (pseudo_joueur, 1, score_niveau1 ))
            connexion.commit()

            messagebox.showinfo("Score sauvegardé", "Votre score a été sauvegardé avec succès !")
        # Fonction pour réinitialiser le jeu
        def reinitialiser_jeu():
            global score, numero_question
            score = 0
            numero_question = 0
            # Mettre à jour le score affiché sur la fenêtre
            self.label_score.config(text="Score: {}".format(score))
            messagebox.showinfo("Jeu réinitialisé", "Le jeu a été réinitialisé. Vous pouvez commencer à nouveau.")
            # Charger la première question
            charger_question()

        # Fonction pour quitter le jeu avec confirmation
            def quitter_jeu(self):
                if messagebox.askyesno("Quitter le jeu", "Voulez-vous sortir du jeu ?"):
                    self.root.destroy()
                    open_jeu(self)


def open_jeu(pseudo_joueur):
    root = Tk(root,pseudo_joueur)
    QuizApp(root)
    root.mainloop()