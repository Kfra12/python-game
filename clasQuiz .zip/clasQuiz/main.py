from tkinter import *
from tkinter import ttk
import sqlite3
from tkinter import messagebox 
from fenetrejeu import jeu_open

class QuizApp:
    def __init__(self, root):
        self.root= root
        self.root.title("Quiz/page de connexion")
        self.root.configure(bg="#77CDF0")
        
        self.top = LabelFrame(self.root)
        self.top.pack(side="top")
        self.label = Label(self.top, font=("Comic Sans MS", 40, "bold"),
                           text="QUIZ", fg="#E70739", anchor="center")
        self.label.grid(row=0, column=3, pady=50)
        
        self.bouton_connecter = Button(self.top, text="Connexion", command=self.connecter)
        self.bouton_inscription = Button(self.top, text="Inscription", command=self.inscription)
        self.bouton_inscription.grid(row=1, column=2)
        self.bouton_connecter.grid(row=1, column=4)
        
    def connecter(self):
        def verifier_joueur():
            pseudo = pseudo_entry.get()
            mot_de_passe = mot_de_passe_entry.get()
            
            # Connexion et vérification dans la base de données
            conn = sqlite3.connect('dbquiz.sqlite3')
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM joueur WHERE pseudo = ? AND mot_de_passe = ?", (pseudo, mot_de_passe))
            joueur = cursor.fetchone()
            conn.close()
            
            if joueur:
                messagebox.showinfo("Connexion réussie", "Connexion réussie")
                connexion_window.destroy()
                jeu_open(joueur[5])
            elif not pseudo or not mot_de_passe:
                messagebox.showwarning("Champs vides", "Veuillez remplir tous les champs")
            else:
                messagebox.showerror("Erreur de connexion", "Veuillez vérifier les informations saisies")
        
        connexion_window = Tk()
        form_frame = Frame(connexion_window)

        title_label = Label(connexion_window, text="Connectez-vous", font=("Comic Sans MS", 24), fg="black", bg="#77CDF0")
        title_label.pack(pady=50)

        # Formulaire de connexion    
        pseudo_label = Label(form_frame, text="Pseudo", font=("Comic Sans MS", 12), fg="black", bg="#77CDF0")
        pseudo_label.grid(row=0, column=0, padx=20, pady=10, sticky="w")

        pseudo_entry = Entry(form_frame, font=("Comic Sans MS", 12))
        pseudo_entry.grid(row=0, column=1, padx=20, pady=10)

        mot_de_passe_label = Label(form_frame, text="Mot de passe", font=("Comic Sans MS", 12), fg="black", bg="#77CDF0")
        mot_de_passe_label.grid(row=1, column=0, padx=20, pady=10, sticky="w")

        mot_de_passe_entry = Entry(form_frame, show="*", font=("Comic Sans MS", 12))
        mot_de_passe_entry.grid(row=1, column=1, padx=20, pady=10)
        form_frame.pack()

        # Bouton Connexion
        connexion_button = Button(connexion_window, text="Se connecter", font=("Comic Sans MS", 14), fg="black", bg="#EEF177", command=verifier_joueur)
        connexion_button.pack(pady=20)

        # Texte et lien pour s'inscrire
        inscription_text = Label(connexion_window, text="Si vous n'avez pas de compte,", font=("Comic Sans MS", 12), fg="black", bg="#77CDF0")
        inscription_text.pack()

        inscription_link = Label(connexion_window, text="inscrivez-vous", font=("Comic Sans MS", 12, "underline"), fg="blue", bg="#77CDF0", cursor="hand2", command=self.inscription)
        inscription_link.pack()
        
    def inscription(self):
        def verifier_joueur():
            nom = nom_entry.get()
            prenom = prenom_entry.get()
            age = age_entry.get()
            email = email_entry.get()
            pseudo = pseudo_entry.get()
            mot_de_passe = mot_de_passe_entry.get()
            
            # Vérification dans la base de données
            conn = sqlite3.connect('dbquiz.sqlite3')
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM joueur WHERE pseudo = ?", (pseudo,))
            existing_joueur = cursor.fetchone()

            if existing_joueur:
                messagebox.showerror("Pseudo existant", "Le pseudo est déjà utilisé par un autre joueur")
            elif not nom or not prenom or not age or not email or not pseudo or not mot_de_passe:
                messagebox.showwarning("Champs vides", "Veuillez remplir tous les champs")
            else:
                # Ajout du joueur à la base de données
                cursor.execute("INSERT INTO joueur (nom, prenom, age, email, pseudo, mot_de_passe) VALUES (?, ?, ?, ?, ?, ?)",
                              (nom, prenom, age, email, pseudo, mot_de_passe))
                conn.commit()
                conn.close()
                messagebox.showinfo("Enregistrement réussi", "Enregistrement réussi")
                inscription_window.destroy()
                self.connecter()
        
        inscription_window = Tk()
        form_frame = Frame(inscription_window)

        title_label = Label(inscription_window, text="inscrivez-vous", font=("Comic Sans MS", 24), fg="black", bg="#77CDF0")
        title_label.pack(pady=50)

        # Formulaire d'inscription
        nom_label = Label(form_frame, text="Nom", font=("Comic Sans MS", 12), fg="black", bg="#77CDF0")
        nom_label.grid(row=0, column=0, padx=20, pady=10, sticky="w")
        nom_entry = Entry(form_frame, font=("Comic Sans MS", 12))
        nom_entry.grid(row=0, column=1, padx=20, pady=10)

        prenom_label = Label(form_frame, text="Prenom", font=("Comic Sans MS", 12), fg="black", bg="#77CDF0")
        prenom_label.grid(row=1, column=0, padx=20, pady=10, sticky="w")
        prenom_entry = Entry(form_frame, font=("Comic Sans MS", 12))
        prenom_entry.grid(row=1, column=1, padx=20, pady=10)

        age_label = Label(form_frame, text="Age", font=("Comic Sans MS", 12), fg="black", bg="#77CDF0")
        age_label.grid(row=2, column=0, padx=20, pady=10, sticky="w")
        age_entry = Entry(form_frame, font=("Comic Sans MS", 12))
        age_entry.grid(row=2, column=1, padx=20, pady=10)

        email_label = Label(form_frame, text="Email", font=("Comic Sans MS", 12), fg="black", bg="#77CDF0")
        email_label.grid(row=3, column=0, padx=20, pady=10, sticky="w")
        email_entry = Entry(form_frame, font=("Comic Sans MS", 12))
        email_entry.grid(row=3, column=1, padx=20, pady=10)

        pseudo_label = Label(form_frame, text="Pseudo", font=("Comic Sans MS", 12), fg="black", bg="#77CDF0")
        pseudo_label.grid(row=4, column=0, padx=20, pady=10, sticky="w")
        pseudo_entry = Entry(form_frame, font=("Comic Sans MS", 12))
        pseudo_entry.grid(row=4, column=1, padx=20, pady=10)

        mot_de_passe_label = Label(form_frame, text="Mot de passe", font=("Comic Sans MS", 12), fg="black", bg="#77CDF0")
        mot_de_passe_label.grid(row=5, column=0, padx=20, pady=10, sticky="w")
        mot_de_passe_entry = Entry(form_frame, show="*", font=("Comic Sans MS", 12))
        mot_de_passe_entry.grid(row=5, column=1, padx=20, pady=10)

        form_frame.pack()

        # Bouton Inscription
        inscription_button = Button(inscription_window, text="S'inscrire", font=("Comic Sans MS", 14), fg="black", bg="#EEF177", command=verifier_joueur)
        inscription_button.pack(pady=20)

        inscription_window.mainloop()


root = Tk()
QuizApp(root)
root.mainloop()
