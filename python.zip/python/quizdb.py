import sqlite3

base = "quizdb.sqlite3"
connexion = sqlite3.connect(base)
curseur = connexion.cursor()

req_joueur = "CREATE TABLE IF NOT EXISTS joueur(id_joueur INTEGER PRIMARY KEY, nom TEXT, prenom TEXT, age INTEGER, email TEXT, pseudo TEXT, mot_de_passe TEXT, score_niveau1 INTEGER, score_niveau2 INTEGER, score_niveau3 INTEGER, score_total INTEGER)"
req_niveau = "CREATE TABLE IF NOT EXISTS niveau (id_niveau INTEGER PRIMARY KEY, niveau TEXT)"
req_question = "CREATE TABLE IF NOT EXISTS question (id_question INTEGER PRIMARY KEY, id_niveau INTEGER, question TEXT, reponse_vrai TEXT, reponse_fausse1 TEXT,reponse_fausse2 TEXT,reponse_fausse3 TEXT, FOREIGN KEY (id_niveau) REFERENCES niveau(id_niveau))"
req_quizz = "CREATE TABLE IF NOT EXISTS quiz(id_quiz INTEGER PRIMARY KEY, id_joueur INTEGER, id_niveau INTEGER, score INTEGER, FOREIGN KEY (id_joueur) REFERENCES joueur (id_joueur), FOREIGN KEY (id_niveau) REFERENCES niveau (id_niveau))"

curseur.execute(req_joueur)
curseur.execute(req_niveau)
curseur.execute(req_question)
curseur.execute(req_quizz)

connexion.commit()
connexion.close()
