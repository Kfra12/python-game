import sqlite3
import tkinter as tk
from tkinter import messagebox

# Fonction pour ajouter une question à la base de données
def ajouter_question():
    question = entry_question.get()
    reponse_vrai = entry_reponse_vrai.get()
    reponse_fausse1 = entry_reponse_fausse1.get()
    reponse_fausse2 = entry_reponse_fausse2.get()
    reponse_fausse3 = entry_reponse_fausse3.get()
    niveau = entry_niveau.get()

    # Vérifier si tous les champs sont remplis
    if not question or not reponse_vrai or not reponse_fausse1 or not reponse_fausse2 or not reponse_fausse3 or not niveau:
        messagebox.showerror("Erreur", "Veuillez remplir tous les champs")
        return

    # Connexion à la base de données
    conn = sqlite3.connect("quizdb.sqlite3")
    cursor = conn.cursor()

    # Ajouter la question à la base de données
    cursor.execute("INSERT INTO question (id_question, id_niveau, question, reponse_vrai, reponse_fausse1, reponse_fausse2, reponse_fausse3,) VALUES (?, ?, ?, ?, ?, ?)",
                   (niveau, question, reponse_vrai, reponse_fausse1, reponse_fausse2, reponse_fausse3))

    conn.commit()
    conn.close()

    # Effacer les champs de saisie
    entry_question.delete(0, tk.END)
    entry_reponse_vrai.delete(0, tk.END)
    entry_reponse_fausse1.delete(0, tk.END)
    entry_reponse_fausse2.delete(0, tk.END)
    entry_reponse_fausse3.delete(0, tk.END)
    entry_niveau.delete(0, tk.END)

    messagebox.showinfo("Succès", "Question ajoutée avec succès")

# Créer la fenêtre principale
window = tk.Tk()
window.title("Questions")
window.geometry("960x650")
window.config(bg="#77CDF0")
window.resizable(False, False)

# Créer le titre
label_titre = tk.Label(window, text="Questions", font=("Comic Sans MS", 16), bg="#77CDF0", pady=10)
label_titre.pack()

# Créer les étiquettes et les champs de saisie
label_question = tk.Label(window, text="Question :", font=("Comic Sans MS", 12), bg="#77CDF0")
label_question.pack(pady=(10, 5))
entry_question = tk.Entry(window, font=("Comic Sans MS", 12))
entry_question.pack()

label_reponse_vrai = tk.Label(window, text="Réponse vraie :", font=("Comic Sans MS", 12), bg="#77CDF0")
label_reponse_vrai.pack(pady=5)
entry_reponse_vrai = tk.Entry(window, font=("Comic Sans MS", 12))
entry_reponse_vrai.pack()

label_reponse_fausse1 = tk.Label(window, text="Réponse fausse 1 :", font=("Comic Sans MS", 12), bg="#77CDF0")
label_reponse_fausse1.pack(pady=5)
entry_reponse_fausse1 = tk.Entry(window, font=("Comic Sans MS", 12))
entry_reponse_fausse1.pack()

label_reponse_fausse2 = tk.Label(window, text="Réponse fausse 2 :", font=("Comic Sans MS", 12), bg="#77CDF0")
label_reponse_fausse2.pack(pady=5)
entry_reponse_fausse2 = tk.Entry(window, font=("Comic Sans MS", 12))
entry_reponse_fausse2.pack()

label_reponse_fausse3 = tk.Label(window, text="Réponse fausse 3 :", font=("Comic Sans MS", 12), bg="#77CDF0")
label_reponse_fausse3.pack(pady=5)
entry_reponse_fausse3 = tk.Entry(window, font=("Comic Sans MS", 12))
entry_reponse_fausse3.pack()

label_niveau = tk.Label(window, text="Niveau :", font=("Comic Sans MS", 12), bg="#77CDF0")
label_niveau.pack(pady=5)
entry_niveau = tk.Entry(window, font=("Comic Sans MS", 12))
entry_niveau.pack()

# Bouton pour ajouter une question
btn_ajouter = tk.Button(window, text="Ajouter", font=("Comic Sans MS", 12), bg="#EEF177", command=ajouter_question)
btn_ajouter.pack(pady=10)

# Lancer la boucle principale
window.mainloop()
