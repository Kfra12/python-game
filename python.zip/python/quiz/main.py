import sqlite3
from tkinter import *
from tkinter import messagebox
from datetime import datetime

# Connexion à la base de données
conn = sqlite3.connect('quizdb.sqlite3')
c = conn.cursor()
# Fermeture de la connexion à la base de données
conn.close()

class QuizApp:
    def __init__(self, master):
        self.master = master
        self.master.title("Quiz/Game")
        self.master.configure(bg="#77CDF0")

        self.create_menu()

    def create_menu(self):
        self.menu_frame = Frame(self.master, bg="#77CDF0")
        self.menu_frame.pack(pady=50)

        label_title = Label(self.menu_frame, text="QUIZ", font=("Comic Sans", 40), bg="#77CDF0")
        label_title.grid(row=0, column=0, columnspan=2, pady=20)

        button_connexion = Button(self.menu_frame, text="Connexion", font=("Comic Sans", 20), bg="#EEF177",
                                  command=self.open_connexion)
        button_connexion.grid(row=1, column=0, padx=10, pady=10)

        button_enregistrement = Button(self.menu_frame, text="S'enregistrer", font=("Comic Sans", 20), bg="#EEF177",
                                       command=self.open_enregistrement)
        button_enregistrement.grid(row=1, column=1, padx=10, pady=10)

    def open_connexion(self):
        self.menu_frame.destroy()
        self.connexion_frame = Frame(self.master, bg="#77CDF0")
        self.connexion_frame.pack(pady=50)

        label_connexion = Label(self.connexion_frame, text="Connexion", font=("Comic Sans", 30), bg="#77CDF0")
        label_connexion.grid(row=0, column=0, columnspan=2, pady=20)

        label_pseudo = Label(self.connexion_frame, text="Pseudo", font=("Comic Sans", 14), bg="#77CDF0")
        label_pseudo.grid(row=1, column=0, padx=10, pady=10)

        self.pseudo_var = StringVar()
        entry_pseudo = Entry(self.connexion_frame, textvariable=self.pseudo_var)
        entry_pseudo.grid(row=1, column=1, padx=10, pady=10)

        label_mot_de_passe = Label(self.connexion_frame, text="Mot de passe", font=("Comic Sans", 14), bg="#77CDF0")
        label_mot_de_passe.grid(row=2, column=0, padx=10, pady=10)

        self.mot_de_passe_var = StringVar()
        entry_mot_de_passe = Entry(self.connexion_frame, textvariable=self.mot_de_passe_var, show="*")
        entry_mot_de_passe.grid(row=2, column=1, padx=10, pady=10)

        button_se_connecter = Button(self.connexion_frame, text="Se connecter", font=("Comic Sans", 16), bg="#EEF177",
                                     command=self.valider_connexion)
        button_se_connecter.grid(row=3, column=0, padx=10, pady=10)

        button_retour = Button(self.connexion_frame, text="Retour", font=("Comic Sans", 16), bg="#EEF177",
                               command=self.retour_menu)
        button_retour.grid(row=3, column=1, padx=10, pady=10)

        lien_s_enregistrer = Label(self.connexion_frame, text="S'enregistrer ici", font=("Comic Sans", 12), fg="blue",
                                   cursor="hand2", bg="#77CDF0")
        lien_s_enregistrer.grid(row=4, column=0, columnspan=2, pady=10)
        lien_s_enregistrer.bind("<Button-1>", lambda e: self.open_enregistrement())

    def open_enregistrement(self):
        self.menu_frame.destroy()
        self.enregistrement_frame = Frame(self.master, bg="#77CDF0")
        self.enregistrement_frame.pack(pady=50)

        label_enregistrement = Label(self.enregistrement_frame, text="S'enregistrer", font=("Comic Sans", 30),
                                     bg="#77CDF0")
        label_enregistrement.grid(row=0, column=0, columnspan=2, pady=20)

        label_nom = Label(self.enregistrement_frame, text="Nom", font=("Comic Sans", 14), bg="#77CDF0")
        label_nom.grid(row=1, column=0, padx=10, pady=10)

        self.nom_var = StringVar()
        entry_nom = Entry(self.enregistrement_frame, textvariable=self.nom_var)
        entry_nom.grid(row=1, column=1, padx=10, pady=10)

        label_prenom = Label(self.enregistrement_frame, text="Prénom", font=("Comic Sans", 14), bg="#77CDF0")
        label_prenom.grid(row=2, column=0, padx=10, pady=10)

        self.prenom_var = StringVar()
        entry_prenom = Entry(self.enregistrement_frame, textvariable=self.prenom_var)
        entry_prenom.grid(row=2, column=1, padx=10, pady=10)

        label_age = Label(self.enregistrement_frame, text="Age", font=("Comic Sans", 14), bg="#77CDF0")
        label_age.grid(row=3, column=0, padx=10, pady=10)

        self.age_var = StringVar()
        entry_age = Entry(self.enregistrement_frame, textvariable=self.age_var)
        entry_age.grid(row=3, column=1, padx=10, pady=10)

        label_email = Label(self.enregistrement_frame, text="Email", font=("Comic Sans", 14), bg="#77CDF0")
        label_email.grid(row=4, column=0, padx=10, pady=10)

        self.email_var = StringVar()
        entry_email = Entry(self.enregistrement_frame, textvariable=self.email_var)
        entry_email.grid(row=4, column=1, padx=10, pady=10)

        label_pseudo = Label(self.enregistrement_frame, text="Pseudo", font=("Comic Sans", 14), bg="#77CDF0")
        label_pseudo.grid(row=5, column=0, padx=10, pady=10)

        self.pseudo_var = StringVar()
        entry_pseudo = Entry(self.enregistrement_frame, textvariable=self.pseudo_var)
        entry_pseudo.grid(row=5, column=1, padx=10, pady=10)

        label_mot_de_passe = Label(self.enregistrement_frame, text="Mot de passe", font=("Comic Sans", 14),
                                   bg="#77CDF0")
        label_mot_de_passe.grid(row=6, column=0, padx=10, pady=10)

        self.mot_de_passe_var = StringVar()
        entry_mot_de_passe = Entry(self.enregistrement_frame, textvariable=self.mot_de_passe_var, show="*")
        entry_mot_de_passe.grid(row=6, column=1, padx=10, pady=10)

        button_s_enregistrer = Button(self.enregistrement_frame, text="S'enregistrer", font=("Comic Sans", 16),
                                      bg="#EEF177", command=self.valider_enregistrement)
        button_s_enregistrer.grid(row=7, column=0, padx=10, pady=10)

        button_retour = Button(self.enregistrement_frame, text="Retour", font=("Comic Sans", 16), bg="#EEF177",
                               command=self.retour_menu)
        button_retour.grid(row=7, column=1, padx=10, pady=10)

        lien_se_connecter = Label(self.enregistrement_frame, text="Se connecter ici", font=("Comic Sans", 12),
                                  fg="blue", cursor="hand2", bg="#77CDF0")
        lien_se_connecter.grid(row=8, column=0, columnspan=2, pady=10)
        lien_se_connecter.bind("<Button-1>", lambda e: self.open_connexion())

    def retour_menu(self):
        self.connexion_frame.destroy()
        self.enregistrement_frame.destroy()
        self.create_menu()

    def valider_connexion(self):
        pseudo = self.pseudo_var.get()
        mot_de_passe = self.mot_de_passe_var.get()

        # Vérification des informations de connexion dans la base de données
        conn = sqlite3.connect('quizdb.sqlite3')
        c = conn.cursor()
        c.execute("SELECT * FROM joueur WHERE pseudo = ? AND mot_de_passe = ?", (pseudo, mot_de_passe))
        joueur = c.fetchone()
        conn.close()

        if joueur:
            messagebox.showinfo("Connexion réussie", "Connexion réussie")
            self.connexion_frame.destroy()
            self.open_jeu(joueur)
        elif not pseudo or not mot_de_passe:
            messagebox.showwarning("Champs vides", "Veuillez remplir tous les champs")
        else:
            messagebox.showerror("Erreur de connexion", "Veuillez vérifier les informations saisies")

    def valider_enregistrement(self):
        nom = self.nom_var.get()
        prenom = self.prenom_var.get()
        age = self.age_var.get()
        email = self.email_var.get()
        pseudo = self.pseudo_var.get()
        mot_de_passe = self.mot_de_passe_var.get()

        # Vérification de l'existence d'un joueur avec le même pseudo dans la base de données
        conn = sqlite3.connect('quizdb.sqlite3')
        c = conn.cursor()
        c.execute("SELECT * FROM joueur WHERE pseudo = ?", (pseudo,))
        existing_joueur = c.fetchone()

        if existing_joueur:
            messagebox.showerror("Pseudo existant", "Le pseudo est déjà utilisé par un autre joueur")
        elif not nom or not prenom or not age or not email or not pseudo or not mot_de_passe:
            messagebox.showwarning("Champs vides", "Veuillez remplir tous les champs")
        else:
            # Ajout du joueur à la base de données
            c.execute("INSERT INTO joueur (nom, prenom, age, email, pseudo, mot_de_passe) VALUES (?, ?, ?, ?, ?, ?)",
                      (nom, prenom, age, email, pseudo, mot_de_passe))
            conn.commit()
            conn.close()
            messagebox.showinfo("Enregistrement réussi", "Enregistrement réussi")
            self.enregistrement_frame.destroy()
            self.open_jeu((self, pseudo,))

    def open_jeu(self, joueur):
        self.joueur = joueur
        self.jeu_frame = Frame(self.master, bg="#77CDF0")
        self.jeu_frame.pack(pady=50)

        label_welcome = Label(self.jeu_frame, text=f"Bienvenue, {joueur[5]}!", font=("Comic Sans", 30), bg="#77CDF0")
        label_welcome.grid(row=0, column=0, columnspan=2, pady=20)

        button_niveau1 = Button(self.jeu_frame, text="Niveau 1", font=("Comic Sans", 16), bg="#EEF177",
                                command=self.start_niveau1)
        button_niveau1.grid(row=1, column=0, padx=10, pady=10)

        button_niveau2 = Button(self.jeu_frame, text="Niveau 2", font=("Comic Sans", 16), bg="#EEF177",
                                command=self.start_niveau2)
        button_niveau2.grid(row=1, column=1, padx=10, pady=10)

        button_niveau3 = Button(self.jeu_frame, text="Niveau 3", font=("Comic Sans", 16), bg="#EEF177",
                                command=self.start_niveau3)
        button_niveau3.grid(row=2, column=0, padx=10, pady=10)

        button_score = Button(self.jeu_frame, text="Voir score", font=("Comic Sans", 16), bg="#EEF177",
                              command=self.view_score)
        button_score.grid(row=2, column=1, padx=10, pady=10)

        button_retour = Button(self.jeu_frame, text="Déconnexion", font=("Comic Sans", 16), bg="#EEF177",
                               command=self.deconnexion)
        button_retour.grid(row=3, column=0, columnspan=2, pady=10)

    def start_niveau1(self):
        self.start_niveau(1)

    def start_niveau2(self):
        self.start_niveau(2)

    def start_niveau3(self):
        self.start_niveau(3)

    def start_niveau(self, niveau):
        self.jeu_frame.destroy()

        # Récupération des questions du niveau depuis la base de données
        conn = sqlite3.connect('quizdb.sqlite3')
        c = conn.cursor()
        c.execute("SELECT * FROM questions WHERE niveau = ?", (niveau,))
        questions = c.fetchall()
        conn.close()

        if not questions:
            messagebox.showerror("Pas de questions", "Il n'y a pas de questions disponibles pour ce niveau.")
            self.open_jeu(self.joueur)
            return

        self.jeu_en_cours_frame = Frame(self.master, bg="#77CDF0")
        self.jeu_en_cours_frame.pack(pady=50)

        self.current_question_index = 0
        self.score = 0

        self.question_label = Label(self.jeu_en_cours_frame, text="", font=("Comic Sans", 16), bg="#77CDF0")
        self.question_label.pack(pady=20)

        self.radio_var = StringVar()
        self.radio_var.set(-1)

        self.radio_buttons = []
        for i in range(4):
            radio_button = Radiobutton(self.jeu_en_cours_frame, text="", font=("Comic Sans", 14), bg="#77CDF0",
                                       variable=self.radio_var, value=i, command=self.update_answer)
            radio_button.pack(pady=5)
            self.radio_buttons.append(radio_button)

        self.next_button = Button(self.jeu_en_cours_frame, text="Suivant", font=("Comic Sans", 16), bg="#EEF177",
                                  state=DISABLED, command=self.next_question)
        self.next_button.pack(pady=20)

        self.display_question(questions[self.current_question_index])

    def display_question(self, question):
        self.question_label.configure(text=question[1])

        for i in range(4):
            self.radio_buttons[i].configure(text=question[i + 2])

    def update_answer(self):
        self.next_button.configure(state=NORMAL)

    def next_question(self):
        selected_answer = int(self.radio_var.get())
        correct_answer = int(self.get_current_question()[6])

        if selected_answer == correct_answer:
            self.score += 1

        self.current_question_index += 1
        self.radio_var.set(-1)

        if self.current_question_index == len(self.questions):
            self.end_game()
        else:
            self.display_question(self.get_current_question())

    def get_current_question(self):
        return self.questions[self.current_question_index]

    def end_game(self):
        messagebox.showinfo("Fin du jeu", f"Votre score final est de {self.score}/{len(self.questions)}")
        self.jeu_en_cours_frame.destroy()
        self.open_jeu(self.joueur)

    def view_score(self):
        conn = sqlite3.connect('quizbd.sqlite3')
        c = conn.cursor()
        c.execute("SELECT score FROM score WHERE joueur_id = ?", (self.joueur[0],))
        scores = c.fetchall()
        conn.close()

        score_text = ""
        if scores:
            score_text = "\n".join([f"Partie {i+1}: {score[0]}/{len(self.questions)}" for i, score in enumerate(scores)])
        else:
            score_text = "Aucun score enregistré."

        messagebox.showinfo("Scores", score_text)

    def deconnexion(self):
        self.jeu_frame.destroy()
        self.joueur = None
        self.create_menu()

root = Tk()
QuizApp(root)
root.mainloop()
